const API_BASE = "http://192.168.1.10:5000";
const USERNAME = "franco";                  

export { API_BASE, USERNAME };
